<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\SystemException;
use Bitrix\Main\Loader;

class NewsList extends CBitrixComponent
{
    public function executeComponent()
    {
        global $USER;
        $this->iBlockId = $this->arParams["IBLOCK_ID"];
        $this->sectionId = $this->arParams["SECTION_ID"] ?: 0;
        $this->limit = $this->arParams["LIMIT"] ?: 100;
        $this->userId = $USER->GetID();
        $this->setCache = true;

        try {
            $this->checkModules();
            $this->getResult();
        } catch (SystemException $e) {
            ShowError($e->getMessage());
        }
    }

    public function onIncludeComponentLang()
    {
        Loc::loadMessages(__FILE__);
    }

    protected function checkModules()
    {
        if (!Loader::includeModule("iblock"))
            throw new SystemException(Loc::getMessage("IBLOCK_MODULE_NOT_INSTALLED"));
    }

    protected function getResult()
    {
        if ($this->startResultCache()) {
            $nav = new \Bitrix\Main\UI\PageNavigation("news");
            $nav->allowAllRecords(true)
                ->setPageSize($this->limit)
                ->initFromUri();

            $filter = ["IBLOCK_ID" => $this->iBlockId];
            if ($this->arParams["SECTION_ID"])
                $filter["IBLOCK_SECTION_ID"] = $this->arParams["SECTION_ID"];
            
            $elementsObj = \Bitrix\Iblock\ElementTable::getList([
                "order" => ["SORT" => "ASC"],
                "select" => ["ID", "NAME", "CODE", "PREVIEW_TEXT", "DETAIL_TEXT","DETAIL_PAGE_URL" => "IBLOCK.DETAIL_PAGE_URL"],
                "filter" => $filter,
                "offset" => $nav->getOffset(),
                "limit" => $nav->getLimit(),
                "count_total" => true,
            ]);

            $arElements = [];
            while ($arItem = $elementsObj->fetch()) {
                $arItem ["DETAIL_PAGE_URL"] =
                    CIBlock::ReplaceDetailUrl($arItem ["DETAIL_PAGE_URL"], $arItem, false, "E");
                $arElements[] = $arItem;
            }

            $nav->setRecordCount($elementsObj->getCount());
            $this->arResult["ITEMS"] = $arElements;
            $this->arResult["NAV"] = $nav;

            if (isset($this->arResult)) {
                $this->SetResultCacheKeys(
                    array("ITEMS")
                );
                $this->IncludeComponentTemplate();
            } else {
                $this->AbortResultCache();
                \Bitrix\Iblock\Component\Tools::process404(
                    Loc::getMessage("PAGE_NOT_FOUND"),
                    true,
                    true
                );
            }
        }
    }
}