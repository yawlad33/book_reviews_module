<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$this->setFrameMode(true);
?>
<div class="news-list">
    <?foreach($arResult["ITEMS"] as $arItem):?>
    <p class="news-item" id="<?=$this->GetEditAreaId($arItem["ID"]);?>">
        <?if($arItem["NAME"]):?>
            <a href="<?echo $arItem["DETAIL_PAGE_URL"]?>"><b><?echo $arItem["NAME"]?></b></a><br />
        <?endif;?>
        <?if($arItem["PREVIEW_TEXT"]):?>
            <?echo $arItem["PREVIEW_TEXT"];?>
        <?endif;?>
        </p>
    <?endforeach;?>
    <?
    $APPLICATION->IncludeComponent(
        "bitrix:main.pagenavigation",
        "",
        array(
            "NAV_OBJECT" => $arResult["NAV"],
            "SEF_MODE" => "N",
        ),
        false
    );
    ?>
</div>
