<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arCurrentValues */

if(!CModule::IncludeModule("iblock"))
    return;

$iblockTypes = Bitrix\Iblock\TypeTable::getList(
    [
        "select" => ["ID", "NAME" => "LANG_MESSAGE.NAME"],
        "filter" => ["=LANG_MESSAGE.LANGUAGE_ID" => "ru"]
    ]
)->FetchAll();
foreach($iblockTypes as $type){
    $arTypesEx[$type["ID"]] = $type["ID"] . " " . $type["NAME"];
}
$arIBlocks=[];
$db_iblock = \Bitrix\Iblock\IblockTable::getList([
    "select" => ["ID","NAME"],
    "filter" => [
        "IBLOCK_TYPE_ID" => $arCurrentValues["IBLOCK_TYPE"]!="-"?$arCurrentValues["IBLOCK_TYPE"]:"",
    ],
]);

while($arRes = $db_iblock->Fetch())
    $arIBlocks[$arRes["ID"]] = "[".$arRes["ID"]."] ".$arRes["NAME"];

$arComponentParameters = array(
    "PARAMETERS" => array(
        "IBLOCK_TYPE" => array(
            "PARENT" => "BASE",
            "NAME" => GetMessage("T_IBLOCK_DESC_LIST_TYPE"),
            "TYPE" => "LIST",
            "VALUES" => $arTypesEx,
            "DEFAULT" => "news",
            "REFRESH" => "Y",
        ),
        "IBLOCK_ID" => array(
            "PARENT" => "BASE",
            "NAME" => GetMessage("T_IBLOCK_DESC_LIST_ID"),
            "TYPE" => "LIST",
            "VALUES" => $arIBlocks,
            "DEFAULT" => '={$_REQUEST["ID"]}',
            "ADDITIONAL_VALUES" => "Y",
            "REFRESH" => "Y",
        ),
        "SECTION_ID" => array(
            "NAME" => "ID раздела",
            "TYPE" => "STRING",
            "DEFAULT" => "",
        ),
        "LIMIT" => array(
            "NAME" => "Количество элементов на странице",
            "TYPE" => "STRING",
            "DEFAULT" => "100",
        ),
    ),
);