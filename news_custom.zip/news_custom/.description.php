<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
    "NAME" => "Список новостей кастом",
    "DESCRIPTION" => "News list на D7",
    "CACHE_PATH" => "Y",
    "SORT" => 30,
    "COMPLEX" => "N",
    "PATH" => array(
        "ID" => "news_custom",
        "NAME" => "Список новостей кастом",
        "CHILD" => "",
    )
);

?>